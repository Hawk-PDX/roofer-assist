class m{constructor(){this.isActive=!1,this.measurementPoints=[],this.overlay=null,this.canvas=null,this.ctx=null,this.scale=null,this.initializeOverlay(),this.bindEvents()}initializeOverlay(){this.overlay=document.createElement("div"),this.overlay.id="roof-measurement-overlay",this.overlay.style.cssText=`
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 10000;
            display: none;
        `,this.canvas=document.createElement("canvas"),this.canvas.style.cssText=`
            width: 100%;
            height: 100%;
            pointer-events: auto;
        `,this.overlay.appendChild(this.canvas),document.body.appendChild(this.overlay),this.ctx=this.canvas.getContext("2d"),this.resizeCanvas(),this.createInfoPanel()}createInfoPanel(){const e=document.createElement("div");e.id="measurement-info-panel",e.style.cssText=`
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 8px;
            padding: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            min-width: 200px;
            display: none;
            z-index: 10001;
        `,e.innerHTML=`
            <div style="font-weight: 600; margin-bottom: 8px; color: #1a73e8;">
                📐 Roof Measurement
            </div>
            <div id="measurement-instructions">
                Click on roof corners to measure. Press ESC to cancel.
            </div>
            <div id="current-measurements" style="margin-top: 8px; font-size: 12px; color: #666;">
                Points: <span id="point-count">0</span>
            </div>
            <div style="margin-top: 12px;">
                <button id="finish-measurement" style="
                    background: #1a73e8;
                    color: white;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 4px;
                    font-size: 12px;
                    cursor: pointer;
                    margin-right: 8px;
                ">Finish</button>
                <button id="clear-measurement" style="
                    background: #dc3545;
                    color: white;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 4px;
                    font-size: 12px;
                    cursor: pointer;
                ">Clear</button>
            </div>
        `,document.body.appendChild(e),this.infoPanel=e,document.getElementById("finish-measurement").addEventListener("click",()=>this.finishMeasurement()),document.getElementById("clear-measurement").addEventListener("click",()=>this.clearMeasurement())}bindEvents(){chrome.runtime.onMessage.addListener((e,t,s)=>{e.action==="startMeasurement"?(this.startMeasurement(),s({status:"started"})):e.action==="stopMeasurement"&&(this.stopMeasurement(),s({status:"stopped"}))}),this.canvas.addEventListener("click",e=>{this.isActive&&this.addMeasurementPoint(e)}),document.addEventListener("keydown",e=>{e.key==="Escape"&&this.isActive&&this.stopMeasurement()}),window.addEventListener("resize",()=>this.resizeCanvas())}resizeCanvas(){const e=this.canvas.getBoundingClientRect();this.canvas.width=e.width*window.devicePixelRatio,this.canvas.height=e.height*window.devicePixelRatio,this.ctx.scale(window.devicePixelRatio,window.devicePixelRatio),this.redrawMeasurements()}startMeasurement(){this.isActive=!0,this.overlay.style.display="block",this.infoPanel.style.display="block",this.canvas.style.cursor="crosshair",this.detectMapScale()}stopMeasurement(){this.isActive=!1,this.overlay.style.display="none",this.infoPanel.style.display="none",this.clearMeasurement()}addMeasurementPoint(e){const t=this.canvas.getBoundingClientRect(),s=e.clientX-t.left,a=e.clientY-t.top;this.measurementPoints.push({x:s,y:a}),this.updatePointCount(),this.redrawMeasurements(),this.measurementPoints.length>=4&&setTimeout(()=>this.finishMeasurement(),500)}clearMeasurement(){this.measurementPoints=[],this.updatePointCount(),this.redrawMeasurements()}updatePointCount(){const e=document.getElementById("point-count");e&&(e.textContent=this.measurementPoints.length)}redrawMeasurements(){if(this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height),this.measurementPoints.length!==0&&(this.ctx.fillStyle="#1a73e8",this.ctx.strokeStyle="#1a73e8",this.ctx.lineWidth=2,this.measurementPoints.forEach((e,t)=>{this.ctx.beginPath(),this.ctx.arc(e.x,e.y,6,0,2*Math.PI),this.ctx.fill(),this.ctx.fillStyle="white",this.ctx.font="12px sans-serif",this.ctx.textAlign="center",this.ctx.fillText((t+1).toString(),e.x,e.y+4),this.ctx.fillStyle="#1a73e8"}),this.measurementPoints.length>1)){this.ctx.beginPath(),this.ctx.moveTo(this.measurementPoints[0].x,this.measurementPoints[0].y);for(let e=1;e<this.measurementPoints.length;e++)this.ctx.lineTo(this.measurementPoints[e].x,this.measurementPoints[e].y);this.measurementPoints.length>=3&&this.ctx.closePath(),this.ctx.strokeStyle="rgba(26, 115, 232, 0.7)",this.ctx.stroke(),this.measurementPoints.length>=3&&(this.ctx.fillStyle="rgba(26, 115, 232, 0.2)",this.ctx.fill())}}detectMapScale(){const e=document.querySelector("[data-value]");if(e){const s=e.textContent.match(/(\\d+)\\s*(m|ft|km|mi)/);s&&(this.scale={value:parseInt(s[1]),unit:s[2]})}this.scale||(this.scale={value:50,unit:"ft"})}finishMeasurement(){if(this.measurementPoints.length<3){alert("Please mark at least 3 points to measure the roof area.");return}const e=this.calculateMeasurements();this.sendMeasurementsToPopup(e),this.stopMeasurement()}calculateMeasurements(){const e=this.measurementPoints;let t=0;for(let i=0;i<e.length;i++){const l=(i+1)%e.length;t+=e[i].x*e[l].y,t-=e[l].x*e[i].y}t=Math.abs(t)/2;const s=this.estimatePixelsPerUnit(),o=t/(s*s),n=this.estimateRoofPitch(),h=Math.sqrt(1+Math.pow(n.rise/n.run,2)),r=o*h,d=r/100;return{groundArea:Math.round(o),roofArea:Math.round(r),pitch:n,shingleSquares:Math.ceil(d*10)/10,pixelsPerUnit:s}}estimatePixelsPerUnit(){const e=window.innerWidth,t=this.scale?this.scale.value*10:500;return e/t}estimateRoofPitch(){return{rise:6,run:12}}sendMeasurementsToPopup(e){chrome.runtime.sendMessage({action:"measurementComplete",data:e})}}new m;const c=document.createElement("style");c.textContent=`
    #roof-measurement-overlay {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    
    #roof-measurement-overlay canvas {
        background: transparent;
    }
    
    .measurement-tooltip {
        position: absolute;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        pointer-events: none;
        z-index: 10002;
    }
`;document.head.appendChild(c);
